export function getStepReturn({ deployEnvVars, event, packageName, newError, newEnvChanges, newStatus, coreStep, coreStepName: timerName, childEnv, mode, api, errorMonitor, deployId, netlifyConfig, configMutations, headersPath, redirectsPath, logs, outputFlusher, debug, timers, durationNs, testOpts, systemLog, quiet, metrics, returnValue, }: {
    deployEnvVars: any;
    event: any;
    packageName: any;
    newError: any;
    newEnvChanges: any;
    newStatus: any;
    coreStep: any;
    coreStepName?: string | undefined;
    childEnv: any;
    mode: any;
    api: any;
    errorMonitor: any;
    deployId: any;
    netlifyConfig: any;
    configMutations: any;
    headersPath: any;
    redirectsPath: any;
    logs: any;
    outputFlusher: any;
    debug: any;
    timers: any;
    durationNs: any;
    testOpts: any;
    systemLog: any;
    quiet: any;
    metrics: any;
    returnValue: any;
}): Promise<{
    failedPlugin: string[];
    newStatus: {
        state: "failed_build" | "failed_plugin" | "canceled_build";
        title: string | (import("../error/types.js").TitleFunction & string);
        summary: string;
        text: string | undefined;
        extraData: any;
    };
}> | Promise<{
    newError: any;
    newStatus: {
        state: "failed_build" | "failed_plugin" | "canceled_build";
        title: string | (import("../error/types.js").TitleFunction & string);
        summary: string;
        text: string | undefined;
        extraData: any;
    };
}> | {
    newError: any;
} | {
    deployEnvVars: any;
    newEnvChanges: any;
    netlifyConfig: any;
    configMutations: any;
    headersPath: any;
    redirectsPath: any;
    newStatus: any;
    timers: any;
    metrics: any;
    returnValue: any;
};

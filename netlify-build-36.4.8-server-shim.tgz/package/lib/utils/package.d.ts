import { type Options, type PackageJson } from 'read-package-up';
type PackageResult = {
    packageJson: PackageJson;
    packageDir?: string;
};
/**
 * Retrieve `package.json` from a specific directory
 */
export declare const getPackageJson: (cwd: string, options?: Omit<Options, "cwd">) => Promise<PackageResult>;
export type { PackageJson };

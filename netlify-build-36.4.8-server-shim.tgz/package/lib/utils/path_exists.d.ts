export declare const pathExists: (path: string) => Promise<boolean>;

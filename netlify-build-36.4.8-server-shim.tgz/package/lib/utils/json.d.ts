export type RootPackageJson = {
    name: string;
    version: string;
};
export declare const importJsonFile: <T>(filePath: string) => Promise<T>;
export declare const ROOT_PACKAGE_JSON: RootPackageJson;
export declare const getVersion: () => string;

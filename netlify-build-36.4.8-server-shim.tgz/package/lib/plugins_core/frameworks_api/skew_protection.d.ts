import { z } from 'zod';
declare const skewProtectionConfigSchema: z.ZodObject<{
    patterns: z.ZodArray<z.ZodString>;
    sources: z.ZodArray<z.ZodObject<{
        type: z.ZodEnum<{
            cookie: "cookie";
            header: "header";
            query: "query";
        }>;
        name: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type SkewProtectionConfig = z.infer<typeof skewProtectionConfigSchema>;
export declare const loadSkewProtectionConfig: (configPath: string) => Promise<{
    patterns: string[];
    sources: {
        type: "cookie" | "header" | "query";
        name: string;
    }[];
} | undefined>;
export {};

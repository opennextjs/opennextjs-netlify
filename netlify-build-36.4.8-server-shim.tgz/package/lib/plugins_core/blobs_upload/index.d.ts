import { type CoreStep } from '../types.js';
export declare const uploadBlobs: CoreStep;

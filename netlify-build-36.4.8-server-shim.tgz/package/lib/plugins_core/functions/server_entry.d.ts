import { type FeatureFlags } from '../../core/feature_flags.js';
export declare const SERVER_ENTRY_FUNCTION_NAME = "___netlify-server";
export interface ServerEntry {
    entryPath: string;
    shimPath: string;
    relativeEntryPath: string;
}
export declare const getServerEntry: ({ buildDir, packagePath, featureFlags, }: {
    buildDir: string;
    packagePath?: string;
    featureFlags?: FeatureFlags;
}) => Promise<ServerEntry | undefined>;

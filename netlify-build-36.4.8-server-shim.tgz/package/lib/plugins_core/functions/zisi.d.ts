import { type FunctionConfig, type ZipFunctionsOptions } from '@netlify/zip-it-and-ship-it';
import type { FeatureFlags } from '../../core/feature_flags.js';
type GetZisiParametersType = {
    branch?: string;
    buildDir: string;
    childEnv: Record<string, string>;
    featureFlags: FeatureFlags;
    functionsConfig: Record<string, any>;
    functionsDist: string;
    internalFunctionsSrc: string | undefined;
    isRunningLocally: boolean;
    repositoryRoot: string;
    userNodeVersion: string;
    systemLog: ZipFunctionsOptions['systemLog'];
};
export declare const getZisiParameters: ({ branch, buildDir, childEnv, featureFlags, functionsConfig, functionsDist, internalFunctionsSrc, isRunningLocally, repositoryRoot, userNodeVersion, systemLog, }: GetZisiParametersType) => ZipFunctionsOptions;
export declare const normalizeFunctionConfig: ({ buildDir, functionConfig, isRunningLocally, nodeVersion, }: {
    buildDir: string;
    functionConfig: Record<string, any>;
    isRunningLocally: boolean;
    nodeVersion: string | undefined;
}) => FunctionConfig;
export {};

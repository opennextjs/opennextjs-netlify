import { zipFunctions, type FunctionResult } from '@netlify/zip-it-and-ship-it';
import type { CoreStepFunction } from '../types.js';
export declare const bundleFunctions: {
    event: string;
    coreStep: CoreStepFunction;
    coreStepId: string;
    coreStepName: string;
    coreStepDescription: () => string;
    condition: ({ buildDir, constants: { INTERNAL_FUNCTIONS_SRC, FUNCTIONS_SRC }, featureFlags, packagePath, returnValues, }: {
        buildDir: any;
        constants: {
            INTERNAL_FUNCTIONS_SRC: any;
            FUNCTIONS_SRC: any;
        };
        featureFlags: any;
        packagePath: any;
        returnValues: any;
    }) => Promise<boolean>;
};
export declare const zipItAndShipIt: {
    zipFunctions(input: import("packages/zip-it-and-ship-it/dist/paths.js").MixedPaths, destFolder: string, args_2?: import("@netlify/zip-it-and-ship-it").ZipFunctionsOptions | undefined): Promise<FunctionResult[]>;
};

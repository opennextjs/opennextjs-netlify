export function addStatus({ newStatus, statuses, event, packageName, pluginPackageJson: { version } }: {
    newStatus: any;
    statuses: any;
    event: any;
    packageName: any;
    pluginPackageJson?: {} | undefined;
}): any;

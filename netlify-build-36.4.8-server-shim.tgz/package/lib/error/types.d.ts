import { type Attributes } from '@opentelemetry/api';
export type BuildError = Omit<BasicErrorInfo, 'errorProps'> & {
    title: string;
    pluginInfo?: string;
    locationInfo?: string;
    errorProps?: string;
};
export type BasicErrorInfo = {
    message: string;
    stack: string;
    severity: string;
    type: ErrorTypes;
    errorInfo: ErrorInfo;
    errorProps: Record<string, unknown>;
    errorMetadata: any;
    /**
     * The core step id where the error took place
     */
    stage?: string;
    tsConfigInfo?: any;
} & ErrorType;
/**
 * Error severity groups the errors emitted by build and used to translate to exit code via SEVERITY_MAP
 */
type ErrorSeverity = 
/**
 * build success
 */
'success'
/**
 * not an error, e.g. build cancellation
 */
 | 'none'
/**
 * user error
 */
 | 'info'
/**
 * community plugin error
 */
 | 'warning'
/**
 * system error, including core plugin error
 */
 | 'error';
/**
 * How the stack trace should appear in the build error logs
 */
type StackType = 
/**
 * not printed
 */
'none' | 'stack'
/**
 * printed as is, but taken from `error.message`. Used when `error.stack` is not being correct due to the error being passed between different processes.
 */
 | 'message';
type GroupFunction = ({ location }: {
    location: ErrorLocation;
}) => string;
export type TitleFunction = ({ location }: {
    location: ErrorLocation;
}) => string;
export type ErrorInfo = {
    plugin?: PluginInfo;
    tsConfig?: any;
    location: ErrorLocation;
};
type PluginInfo = {
    packageName: string;
    pluginPackageJson: {
        version?: string;
    };
    extensionMetadata?: {
        slug: string;
        name: string;
        version: string;
        has_build: boolean;
        has_connector: boolean;
        author?: string;
    };
};
export type BuildCommandLocation = {
    buildCommand: string;
    buildCommandOrigin: string;
};
export declare const isBuildCommandLocation: (location?: ErrorLocation) => location is BuildCommandLocation;
export type FunctionsBundlingLocation = {
    functionName: string;
    functionType: string;
};
export declare const isFunctionsBundlingLocation: (location?: ErrorLocation) => location is FunctionsBundlingLocation;
export type CoreStepLocation = {
    coreStepName: string;
};
export declare const isCoreStepLocation: (location?: ErrorLocation) => location is CoreStepLocation;
export type PluginLocation = {
    event: string;
    packageName: string;
    loadedFrom: string;
    origin: string;
    input?: string;
};
export declare const isPluginLocation: (location?: ErrorLocation) => location is PluginLocation;
export type APILocation = {
    endpoint: string;
    parameters?: any;
};
export declare const isAPILocation: (location?: ErrorLocation) => location is APILocation;
export type DeployLocation = {
    statusCode: string;
};
export declare const isDeployLocation: (location?: ErrorLocation) => location is DeployLocation;
export type ErrorLocation = BuildCommandLocation | FunctionsBundlingLocation | CoreStepLocation | PluginLocation | APILocation | DeployLocation;
/**
 * Given a BuildError, extract the relevant trace attributes to add to the on-going Span
 */
export declare const buildErrorToTracingAttributes: (error: BuildError | BasicErrorInfo) => Attributes;
/**
 * Retrieve error-type specific information
 */
export declare const getTypeInfo: ({ type }: {
    type: any;
}) => any;
/**
 * Interface for build error types
 */
export interface ErrorType {
    /**
     *  main title shown in build error logs and in the UI (statuses)
     */
    title: TitleFunction | string;
    /**
     *  retrieve a human-friendly location of the error, printed
     */
    locationType?: string;
    /**
     *  `true` when the `Error` instance static properties
     */
    showErrorProps?: boolean;
    /**
     *  `true` when the stack trace should be cleaned up
     */
    rawStack?: boolean;
    /**
     *  `true` when we want this error to show in build logs (defaults to true)
     */
    showInBuildLog?: boolean;
    /**
     *  main title shown in Bugsnag. Also used to group errors together in Bugsnag, combined with `error.message`. Defaults to `title`.
     */
    group?: GroupFunction;
    /**
     *  error severity (also used by Bugsnag)
     */
    severity: ErrorSeverity;
    /**
     *  how the stack trace should appear in build error logs
     */
    stackType: StackType;
}
type ErrorTypeMap = 
/**
 * Plugin called `utils.build.cancelBuild()`
 */
'cancelBuild' | 'resolveConfig' | 'dependencies' | 'pluginInput' | 'pluginUnsupportedVersion' | 'buildCommand' | 'functionsBundling' | 'secretScanningFoundSecrets' | 'failPlugin' | 'failBuild' | 'pluginValidation' | 'pluginInternal' | 'ipc' | 'corePlugin' | 'trustedPlugin' | 'coreStep' | 'api' | 'deploy' | 'deployInternal' | 'exception' | 'telemetry';
export type ErrorTypes = ErrorTypeMap;
export declare const DEFAULT_TITLE: string;
export {};

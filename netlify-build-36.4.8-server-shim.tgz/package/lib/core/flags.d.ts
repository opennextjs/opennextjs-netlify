export const FLAGS: {
    config: {
        string: boolean;
        describe: string;
    };
    defaultConfig: {
        string: boolean;
        describe: string;
        coerce: (value: any) => any;
        hidden: boolean;
    };
    cachedConfig: {
        string: boolean;
        describe: string;
        coerce: (value: any) => any;
        hidden: boolean;
    };
    cachedConfigPath: {
        string: boolean;
        describe: string;
        hidden: boolean;
    };
    cwd: {
        string: boolean;
        describe: string;
    };
    repositoryRoot: {
        string: boolean;
        describe: string;
    };
    packagePath: {
        string: boolean;
        describe: string;
    };
    apiHost: {
        string: boolean;
        describe: string;
    };
    token: {
        string: boolean;
        describe: string;
    };
    siteId: {
        string: boolean;
        describe: string;
    };
    accountId: {
        string: boolean;
        describe: string;
    };
    deployId: {
        string: boolean;
        describe: string;
    };
    buildId: {
        string: boolean;
        describe: string;
    };
    skewProtectionToken: {
        string: boolean;
        describe: string;
        hidden: boolean;
    };
    context: {
        string: boolean;
        describe: string;
    };
    branch: {
        string: boolean;
        describe: string;
    };
    framework: {
        string: boolean;
        describe: string;
        hidden: boolean;
    };
    baseRelDir: {
        boolean: boolean;
        describe: string;
        hidden: boolean;
    };
    dry: {
        alias: string;
        boolean: boolean;
        describe: string;
    };
    nodePath: {
        string: boolean;
        describe: string;
    };
    functionsDistDir: {
        string: boolean;
        describe: string;
        hidden: boolean;
    };
    edgeFunctionsDistDir: {
        string: boolean;
        describe: string;
        hidden: boolean;
    };
    cacheDir: {
        string: boolean;
        describe: string;
        hidden: boolean;
    };
    buildbotServerSocket: {
        string: boolean;
        describe: string;
        hidden: boolean;
    };
    telemetry: {
        boolean: boolean;
        describe: string;
    };
    mode: {
        string: boolean;
        describe: string;
        hidden: boolean;
    };
    debug: {
        boolean: boolean;
        describe: string;
        hidden: boolean;
    };
    systemLogFile: {
        type: string;
        describe: string;
        hidden: boolean;
    };
    verbose: {
        boolean: boolean;
        describe: string;
        hidden: boolean;
    };
    sendStatus: {
        boolean: boolean;
        describe: string;
        hidden: boolean;
    };
    saveConfig: {
        boolean: boolean;
        describe: string;
        hidden: boolean;
    };
    outputConfigPath: {
        type: string;
        describe: string;
        hidden: boolean;
    };
    testOpts: {
        describe: string;
        hidden: boolean;
    };
    featureFlags: {
        describe: string;
        hidden: boolean;
    };
    statsd: {
        describe: string;
        hidden: boolean;
    };
    'statsd.host': {
        type: string;
        describe: string;
        hidden: boolean;
    };
    'statsd.port': {
        type: string;
        describe: string;
        hidden: boolean;
    };
    offline: {
        boolean: boolean;
        describe: string;
    };
    buffer: {
        boolean: boolean;
        describe: string;
    };
    timeline: {
        string: boolean;
        describe: string;
        hidden: boolean;
    };
    explicitSecretKeys: {
        type: string;
        describe: string;
        hidden: boolean;
    };
    enhancedSecretScan: {
        boolean: boolean;
        hidden: boolean;
        describe: string;
    };
};

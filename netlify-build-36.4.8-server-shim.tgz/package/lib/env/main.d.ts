export declare const getChildEnv: ({ envOpt, env: allConfigEnv }: {
    envOpt: any;
    env: any;
}) => {
    [k: string]: unknown;
};

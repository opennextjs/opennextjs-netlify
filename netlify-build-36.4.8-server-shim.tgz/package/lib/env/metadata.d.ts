export function getEnvMetadata(childEnv?: NodeJS.ProcessEnv): {
    [k: string]: string | undefined;
};

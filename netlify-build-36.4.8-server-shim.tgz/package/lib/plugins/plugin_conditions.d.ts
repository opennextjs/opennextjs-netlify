import { type PackageJson } from 'read-package-up';
import { type PluginVersion } from './list.js';
type ConditionContext = {
    nodeVersion: string;
    packageJson: PackageJson;
    buildDir: string;
    packagePath?: string;
};
type PluginCondition = PluginVersion['conditions'][number]['condition'];
export type Condition = {
    test: (condition: PluginCondition, ctx: ConditionContext) => boolean | Promise<boolean>;
    warning: (condition: PluginCondition) => void;
};
export declare const CONDITIONS: {
    nodeVersion: {
        test: (allowedNodeVersion: string, { nodeVersion }: ConditionContext) => boolean;
        warning: (allowedNodeVersion: string) => string;
    };
    siteDependencies: {
        test: (allowedSiteDependencies: Record<string, string>, { packageJson: { devDependencies, dependencies }, packagePath, buildDir }: ConditionContext) => Promise<boolean>;
        warning: (allowedSiteDependencies: any) => string;
    };
};
export {};

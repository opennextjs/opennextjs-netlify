export type ConfigMutation = {
    keys: string[];
    keysString: string;
    value: unknown;
    event: string;
};
export declare function cloneNetlifyConfig<T>(netlifyConfig: T): T;
export declare function getConfigMutations(netlifyConfig: object, netlifyConfigCopy: object, event: string): ConfigMutation[];

export function run({ event, error, constants, envChanges, featureFlags, netlifyConfig, otelCarrier, extensionMetadata }: {
    event: any;
    error: any;
    constants: any;
    envChanges: any;
    featureFlags: any;
    netlifyConfig: any;
    otelCarrier: any;
    extensionMetadata: any;
}, { methods, inputs, packageJson, verbose }: {
    methods: any;
    inputs: any;
    packageJson: any;
    verbose: any;
}): Promise<{
    deployEnvVars: any[];
    newEnvChanges: any;
    configMutations: import("./diff.js").ConfigMutation[];
    returnValue: {
        generatedFunctions: any[];
    } | undefined;
}>;

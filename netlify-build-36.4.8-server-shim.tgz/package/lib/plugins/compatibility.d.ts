import { type PackageJson } from 'read-package-up';
import { FeatureFlags } from '../core/feature_flags.js';
import { SystemLogger } from '../plugins_core/types.js';
import { PluginVersion } from './list.js';
/**
 *  Retrieve the `expectedVersion` of a plugin:
 *   - This is the version which should be run
 *   - This takes version pinning into account
 *   - If this does not match the currently cached version, it is installed first
 *  This is also used to retrieve the `compatibleVersion` of a plugin
 *   - This is the most recent version compatible with this site
 *   - This is the same logic except it does not use version pinning
 *   - This is only used to print a warning message when the `compatibleVersion`
 *     is older than the currently used version.
 */
export declare const getExpectedVersion: ({ versions, nodeVersion, packageJson, packageName, packagePath, buildDir, pinnedVersion, featureFlags, systemLog, authoritative, }: {
    versions: PluginVersion[];
    /** The package.json of the repository */
    packageJson: PackageJson;
    packageName: string;
    packagePath?: string;
    buildDir: string;
    nodeVersion: string;
    pinnedVersion?: string;
    featureFlags?: FeatureFlags;
    systemLog: SystemLogger;
    authoritative?: boolean;
}) => Promise<{
    version: string;
    compatWarning: string;
}>;

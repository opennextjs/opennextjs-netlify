import { type PackageJson } from 'read-package-up';
export declare const getPluginsOptions: ({ timers, ...opts }: {
    [x: string]: any;
    timers: any;
}, ...args: any[]) => Promise<any>;
/**
 * Retrieve information about @netlify/build when an error happens there and not
 * in a plugin
 */
export declare const getSpawnInfo: () => {
    plugin: {
        packageName: string;
        pluginPackageJson: PackageJson;
    };
    location: {
        event: "load";
        packageName: string;
        loadedFrom: "core";
        origin: "core";
    };
};

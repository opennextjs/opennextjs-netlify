export type PluginsLoadedFrom = 'auto_install' | 'local' | 'package.json';
export type PluginsOptions = {
    packageName: string;
    pluginPath?: any;
    pinnedVersion?: any;
    loadedFrom: PluginsLoadedFrom;
    origin: 'config' | string;
    inputs: Record<string, any>;
    pluginPackageJson?: Record<string, any>;
};
/**
 * Local plugins and `package.json`-installed plugins use user's preferred Node.js version if higher than our minimum
 * supported version. Else default to the system Node version.
 * Local and programmatic builds use `@netlify/build` Node.js version, which is
 * usually the system's Node.js version.
 * If the user Node version does not satisfy our supported engine range use our own system Node version
 */
export declare const addPluginsNodeVersion: ({ pluginsOptions, nodePath, userNodeVersion, logs }: {
    pluginsOptions: any;
    nodePath: any;
    userNodeVersion: any;
    logs: any;
}) => Promise<any[]>;

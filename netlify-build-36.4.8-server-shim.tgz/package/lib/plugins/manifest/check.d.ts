export function checkInputs({ inputs, manifest: { inputs: rules }, packageName, pluginPackageJson, loadedFrom, origin, }: {
    inputs: any;
    manifest: {
        inputs?: never[] | undefined;
    };
    packageName: any;
    pluginPackageJson: any;
    loadedFrom: any;
    origin: any;
}): any;

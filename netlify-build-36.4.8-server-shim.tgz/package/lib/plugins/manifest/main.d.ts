import { type PackageJson } from 'read-package-up';
/**
 * Load plugin's `manifest.yml`
 */
export declare const useManifest: ({ packageName, loadedFrom, origin, inputs, }: {
    packageName: string;
    loadedFrom?: unknown;
    origin?: unknown;
    inputs?: unknown;
}, { pluginDir, packageDir, pluginPackageJson, pluginPackageJson: { version }, debug, }: {
    pluginDir: string;
    packageDir?: string;
    pluginPackageJson: PackageJson;
    debug: boolean;
}) => Promise<{
    manifest: any;
    inputs: any;
}>;

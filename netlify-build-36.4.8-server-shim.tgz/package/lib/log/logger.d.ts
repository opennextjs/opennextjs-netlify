import type { SystemLogger } from '../plugins_core/types.js';
import { OutputFlusher } from './output_flusher.js';
export type Logs = BufferedLogs | StreamedLogs;
export type BufferedLogs = {
    stdout: string[];
    stderr: string[];
    outputFlusher?: OutputFlusher;
};
export type StreamedLogs = {
    outputFlusher?: OutputFlusher;
    logFunction?: (message: string) => void;
};
export declare const logsAreBuffered: (logs: Logs | undefined) => logs is BufferedLogs;
/**
 * When the `buffer` option is true, we return logs instead of printing them
 * on the console. The logs are accumulated in a `logs` array variable.
 */
export declare const getBufferLogs: (config: {
    buffer?: boolean;
    logger?: (message: string) => void;
}) => Logs | undefined;
export declare const log: (logs: Logs | undefined, string: string, config?: {
    indent?: boolean;
    color?: (string: string) => string;
}) => void;
export type LogOutput = Pick<BufferedLogs, 'stderr' | 'stdout'>;
export declare const getLogsOutput: (logs: Logs | undefined) => LogOutput;
export declare const logError: (logs: Logs | undefined, string: string, opts?: {}) => void;
export declare const logWarning: (logs: Logs | undefined, string: string, opts?: {}) => void;
export declare const logMessage: (logs: Logs | undefined, string: string, opts?: {}) => void;
export declare const logObject: (logs: Logs | undefined, object: any, opts: any) => void;
export declare const logArray: (logs: Logs | undefined, array: any, opts?: {}) => void;
export declare const logWarningArray: (logs: Logs | undefined, array: any, opts?: {}) => void;
export declare const logHeader: (logs: Logs | undefined, string: string, opts?: {}) => void;
export declare const logErrorHeader: (logs: Logs | undefined, string: string, opts?: {}) => void;
export declare const logSubHeader: (logs: Logs | undefined, string: string, opts?: {}) => void;
export declare const logErrorSubHeader: (logs: Logs | undefined, string: string, opts?: {}) => void;
export declare const logWarningSubHeader: (logs: Logs | undefined, string: string, opts?: {}) => void;
export declare const reduceLogLines: (lines: any) => any;
/**
 * Builds a function for logging data to the system logger (i.e. hidden from
 * the user-facing build logs)
 */
export declare const getSystemLogger: (logs: Logs | undefined, debug: boolean, 
/** A system log file descriptor, if non is provided it will be a noop logger */
systemLogFile?: number) => SystemLogger;
export declare const addOutputFlusher: (logs: Logs, outputFlusher: OutputFlusher) => Logs;

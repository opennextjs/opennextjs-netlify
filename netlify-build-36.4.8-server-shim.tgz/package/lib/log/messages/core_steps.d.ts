export function logBundleResults({ logs, results }: {
    logs: any;
    results: import("@netlify/zip-it-and-ship-it").FunctionResult[];
}): void;
export function trackBundleResults({ results, systemLog }: {
    results: import("@netlify/zip-it-and-ship-it").FunctionResult[];
    systemLog: (...args: unknown[]) => void;
}): {
    bundlers: import("@netlify/zip-it-and-ship-it").NodeBundlerName[];
    fallbackCount: number;
    warningsCount: number;
};
export function logFunctionsNonExistingDir(logs: any, relativeFunctionsSrc: any): void;
export function logFunctionsToBundle({ logs, userFunctions, userFunctionsSrc, userFunctionsSrcExists, internalFunctions, internalFunctionsSrc, frameworkFunctions, generatedFunctions, type, }: {
    logs: any;
    userFunctions: any;
    userFunctionsSrc: any;
    userFunctionsSrcExists: any;
    internalFunctions: any;
    internalFunctionsSrc: any;
    frameworkFunctions: any;
    generatedFunctions: any;
    type?: string | undefined;
}): void;
export function logDbProvisioning({ logs, branch, context }: {
    logs: any;
    branch: any;
    context: any;
}): void;
export function logDbMigrations({ logs, migrations, srcDir }: {
    logs: any;
    migrations: any;
    srcDir: any;
}): void;
export function logSecretsScanSkipMessage(logs: any, msg: any): void;
export function logSecretsScanSuccessMessage(logs: any, msg: any): void;
export function logSecretsScanFailBuildMessage({ logs, scanResults, groupedResults }: {
    logs: any;
    scanResults: any;
    groupedResults: any;
}): void;

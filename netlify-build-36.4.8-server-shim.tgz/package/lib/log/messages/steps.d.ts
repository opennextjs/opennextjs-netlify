export function logStepStart({ logs, event, packageName, coreStepDescription, error, netlifyConfig }: {
    logs: any;
    event: any;
    packageName: any;
    coreStepDescription: any;
    error: any;
    netlifyConfig: any;
}): void;
export function logBuildCommandStart(logs: any, buildCommand: any): void;

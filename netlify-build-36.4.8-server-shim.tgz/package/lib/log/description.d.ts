export declare const getBuildCommandDescription: (buildCommandOrigin: any) => any;
/** Retrieve human-friendly plugin origin */
export declare const getPluginOrigin: (loadedFrom: "package.json" | string, origin: string) => string;
